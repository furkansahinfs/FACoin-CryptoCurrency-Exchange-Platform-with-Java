package controller;

public interface IConsumable {

	/**
	 * This function consumes not used warning
	 */
	public void supressNotUsed();

}
