package controller;

/**
 * This class implements IConsumable for classes that has extends port
 */
public class Consumable implements IConsumable{

	@Override
	public void supressNotUsed() {
	}

}
