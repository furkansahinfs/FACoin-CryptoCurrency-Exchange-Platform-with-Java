package app;

import configuration.Startup;

public class App {

	public static void main(String[] args) {
		final Startup startup = new Startup();
		startup.START();
	}
}
