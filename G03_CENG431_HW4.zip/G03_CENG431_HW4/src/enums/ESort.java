package enums;

/**
 * This enum holds sort types of the system
 */
public enum ESort {
	ASCENDING,DESCENDING,DEFAULT;
}
