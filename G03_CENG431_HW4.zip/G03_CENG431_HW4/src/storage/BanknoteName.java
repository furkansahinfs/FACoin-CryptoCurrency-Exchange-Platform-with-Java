package storage;

/**
 * This class helps containers to compare easily while compraing Banknote names
 */
public class BanknoteName extends Name {

	public String name;

	public BanknoteName(String name) {
		super(name);
	}
}
