package view.list;

import javax.swing.DefaultListModel;
import javax.swing.JLabel;

/**
 * This class holds Coin informations
 */
public class CoinList extends List {

	private static final long serialVersionUID = 1L;

	public CoinList(DefaultListModel<JLabel> listModel) {
		super(listModel);
	}

}
