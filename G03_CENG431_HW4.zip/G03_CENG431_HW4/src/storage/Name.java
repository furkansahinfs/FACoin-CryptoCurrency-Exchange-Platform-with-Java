package storage;

/**
 * This class is for compare element for containers
 */
public class Name {

	public String name;

	public Name(String name) {
		this.name = name;
	}
}