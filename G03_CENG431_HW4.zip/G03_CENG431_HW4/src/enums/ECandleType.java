package enums;

/**
 * This enum holds candle types of the system
 */
public enum ECandleType {
	DAY, HOUR;
}
