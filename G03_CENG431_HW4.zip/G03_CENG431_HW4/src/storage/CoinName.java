package storage;

/**
 * This class helps containers to compare easily while compraing Coin names
 */
public class CoinName extends Name {

	public CoinName(String name) {
		super(name);
	}

}
