package view.list;

import javax.swing.DefaultListModel;
import javax.swing.JLabel;

/**
 * This class holds Wallet informations
 */
public class WalletEntityList extends List {

	private static final long serialVersionUID = 1L;

	public WalletEntityList(DefaultListModel<JLabel> listModel) {
		super(listModel);
	}

}
