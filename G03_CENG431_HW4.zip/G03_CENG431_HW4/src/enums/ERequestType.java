package enums;

/**
 * This enum holds request types of the system
 */
public enum ERequestType {
	GET;
}
